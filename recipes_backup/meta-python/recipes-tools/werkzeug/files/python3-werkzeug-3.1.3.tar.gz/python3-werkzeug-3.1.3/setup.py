from setuptools import setup, find_packages

setup(
    name="Werkzeug",
    version="3.1.3",
    description="A WSGI utility library for Python",
    author="Pallets Team",
    license="BSD-3-Clause",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    include_package_data=True,
    python_requires=">=3.8",
    install_requires=[],
    classifiers=[
        "License :: OSI Approved :: BSD License",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
    ],
)
