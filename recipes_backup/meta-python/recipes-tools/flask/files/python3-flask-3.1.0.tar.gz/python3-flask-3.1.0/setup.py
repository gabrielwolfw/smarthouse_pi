from setuptools import setup, find_packages

setup(
    name="Flask",
    version="3.1.0",
    description="A simple framework for building web applications.",
    author="Pallets Team",
    license="BSD-3-Clause",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    include_package_data=True,
    python_requires=">=3.8",
    install_requires=[
        "Werkzeug",
        "Jinja2",
        "itsdangerous",
        "click"
    ],
    classifiers=[
        "License :: OSI Approved :: BSD License",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
    ],
)
