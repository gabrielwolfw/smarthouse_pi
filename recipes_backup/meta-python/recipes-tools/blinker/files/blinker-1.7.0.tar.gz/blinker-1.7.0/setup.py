from setuptools import setup, find_packages

setup(
    name="blinker",
    version="1.7.0",
    description="Fast, simple object-to-object and broadcast signaling",
    author="Armin Ronacher",
    author_email="armin.ronacher@active-4.com",
    url="https://pythonhosted.org/blinker/",
    license="MIT",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
    python_requires=">=3.6",
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries",
    ],
)
